exports.handler = async function(event) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const body = JSON.parse(event.body);

    // Envoi via EmailJS API
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: 'service_l0wg71l',
        template_id: '8bkjxu4',
        user_id: 'egq016Eb6yWUhZ03o',
        template_params: {
          to_email: body.to,
          nom: body.nom || '',
          mois: body.mois || '',
          annee: body.annee || '2025',
          bailleur: body.bailleur || '',
          bien: body.bien || '',
          adresse: body.adresse || '',
          loyer: body.loyer || '',
          message: body.html || body.message || ''
        }
      })
    });

    const text = await response.text();

    if (response.status === 200) {
      return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
    } else {
      return { statusCode: response.status, headers, body: JSON.stringify({ error: text }) };
    }

  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
